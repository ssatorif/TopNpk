﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TopNPK.Entities;
using System.Configuration;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Markup;
using System.Data;

namespace TopNPK.PageInUserProfile
{
    /// <summary>
    /// Логика взаимодействия для PageStatistics.xaml
    /// </summary>
    public partial class PageStatistics : Page
    {
        public PageStatistics()
        {
            InitializeComponent();

            string connectionString = @" Server=MAIN406\MAINSQLSERVER;
            Database=TopnNPK; user id = wsr-24-406; password = wsr-24-406; multipleactiveresultsets = True; application name = EntityFramework
            Trusted_Connection=True; MultipleActiveResultSets=True";
            SqlConnection connection = new SqlConnection(connectionString);

            string query = "SELECT FirstName, LastName FROM Students";
            SqlCommand command = new SqlCommand(query, connection);

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            List<Student> studentList = dataTable.AsEnumerable()
                .Select(row => new Student
                {
                    FirstName = row.Field<string>("FirstName"),
                    LastName = row.Field<string>("LastName"),
                   
                })
                .ToList();

            studentGrid.ItemsSource = studentList;
        }
    }

    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
      
    }
}


