﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TopNPK.Entities;

namespace TopNPK.Pages
{
    public partial class PageEntry : Page
    {
        public PageEntry()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            string firstname = txbFirstName.Text;
            string lastname = txbLastName.Text;
            string password = pswbPassword.Password;

            var CurrentUser = AppData.db.Students.FirstOrDefault(u => u.FirstName == txbFirstName.Text && u.LastName == txbLastName.Text && u.Password == pswbPassword.Password);

            if (CurrentUser != null)
            {
                NavigationService.Navigate(new PageMainMenu());
            }
            else
            {
                MessageBox.Show("Данные введены некорректно, повторите попытку");
               
                pswbPassword.Clear();
            }
        }

        private void btnForgotPassword_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Вы можете узнать эту информацию у каратора группы");
        }
    }
}
