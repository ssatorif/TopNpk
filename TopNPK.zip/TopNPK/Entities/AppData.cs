﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TopNPK.Entities
{
    public static class AppData
    {
        public static TopnNPKEntities db = new TopnNPKEntities();
    }
}
